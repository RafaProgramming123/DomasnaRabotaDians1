package com.example.kulturnostoriskonasledstvo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KulturnostoriskoNasledstvoApplication {

    public static void main(String[] args) {
        SpringApplication.run(KulturnostoriskoNasledstvoApplication.class, args);
    }

}
