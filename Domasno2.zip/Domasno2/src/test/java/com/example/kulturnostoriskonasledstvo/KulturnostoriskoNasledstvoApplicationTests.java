package com.example.kulturnostoriskonasledstvo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KulturnostoriskoNasledstvoApplicationTests {

    @Test
    void contextLoads() {
    }

}
